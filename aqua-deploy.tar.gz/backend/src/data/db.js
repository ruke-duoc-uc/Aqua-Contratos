/**
 * Capa de persistencia en base de datos para Aqua-Contratos
 * Implementa almacenamiento NoSQL en MongoDB mediante Mongoose (async/await),
 * con respaldo automático en archivos JSON si el servicio MongoDB local no está activo.
 */
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import {
    AreaTrabajoModel,
    CandidatoModel,
    PuestoTrabajoModel,
    PostulacionModel,
    SolicitudInformeModel,
    UsuarioModel,
    EtiquetaModel,
} from "./models.js";
import {
    AREAS_SEED,
    CANDIDATOS_SEED,
    CATALOGOS_SEED,
    INFORMES_SEED,
    PUESTOS_SEED,
    POSTULACIONES_SEED,
    USUARIOS_SEED,
    ETIQUETAS_SEED,
} from "./seedData.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.resolve(__dirname, "../../.env") });

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/aqua_contratos";

const JSON_CANDIDATOS_FILE = path.join(__dirname, "aqua_contratos.json");
const JSON_INFORMES_FILE = path.join(__dirname, "aqua_informes.json");
const JSON_PUESTOS_FILE = path.join(__dirname, "aqua_puestos.json");
const JSON_POSTULACIONES_FILE = path.join(__dirname, "aqua_postulaciones.json");
const JSON_USUARIOS_FILE = path.join(__dirname, "aqua_usuarios.json");
const JSON_AREAS_FILE = path.join(__dirname, "aqua_areas.json");
const JSON_ETIQUETAS_FILE = path.join(__dirname, "aqua_etiquetas.json");

let useMongo = false;

// Stores en memoria para fallback JSON cuando mongod no está en ejecución
let memoryStoreCandidatos = [];
let memoryStoreInformes = [];
let memoryStorePuestos = [];
let memoryStorePostulaciones = [];
let memoryStoreUsuarios = [];
let memoryStoreAreas = [];
let memoryStoreEtiquetas = [];

const limpiarRut = (rut) => (rut || "").replace(/[.-]/g, "").trim().toLowerCase();

function inicializarFallbackJson() {
    const cargarJSON = (archivo, datosIniciales) => {
        if (fs.existsSync(archivo)) {
            try {
                const parsed = JSON.parse(fs.readFileSync(archivo, "utf-8"));
                if (Array.isArray(parsed) && parsed.length > 0) return parsed;
            } catch {
                // Ignorar error y regenerar
            }
        }
        const copia = JSON.parse(JSON.stringify(datosIniciales));
        try {
            fs.writeFileSync(archivo, JSON.stringify(copia, null, 2), "utf-8");
        } catch {
            // Ignorar error de escritura
        }
        return copia;
    };

    memoryStoreCandidatos = cargarJSON(JSON_CANDIDATOS_FILE, CANDIDATOS_SEED);
    memoryStorePuestos = cargarJSON(JSON_PUESTOS_FILE, PUESTOS_SEED);
    memoryStorePostulaciones = cargarJSON(JSON_POSTULACIONES_FILE, POSTULACIONES_SEED);
    memoryStoreInformes = cargarJSON(JSON_INFORMES_FILE, INFORMES_SEED);
    memoryStoreUsuarios = cargarJSON(JSON_USUARIOS_FILE, USUARIOS_SEED);
    memoryStoreAreas = cargarJSON(JSON_AREAS_FILE, AREAS_SEED);
    memoryStoreEtiquetas = cargarJSON(JSON_ETIQUETAS_FILE, ETIQUETAS_SEED);

    // Asegurar que todos los usuarios semilla existan en el fallback
    for (const uSeed of USUARIOS_SEED) {
        if (!memoryStoreUsuarios.some((u) => u.email.toLowerCase() === uSeed.email.toLowerCase())) {
            memoryStoreUsuarios.push({ ...uSeed });
        }
    }

    // Asegurar que todas las postulaciones semilla existan en el fallback
    for (const posSeed of POSTULACIONES_SEED) {
        if (!memoryStorePostulaciones.some((p) => Number(p.id) === Number(posSeed.id))) {
            memoryStorePostulaciones.push({ ...posSeed });
        }
    }

    // Normalizar informes en el fallback (sincronizar preguntas y preguntasJefatura)
    memoryStoreInformes = (memoryStoreInformes || []).map((inf) => {
        const listaPreguntas =
            Array.isArray(inf.preguntasJefatura) && inf.preguntasJefatura.length > 0
                ? inf.preguntasJefatura
                : Array.isArray(inf.preguntas)
                ? inf.preguntas
                : [];
        return {
            ...inf,
            preguntas: listaPreguntas,
            preguntasJefatura: listaPreguntas,
        };
    });
}

function persistJson(tipo) {
    if (useMongo) return;
    try {
        if (tipo === "candidatos" || !tipo) fs.writeFileSync(JSON_CANDIDATOS_FILE, JSON.stringify(memoryStoreCandidatos, null, 2), "utf-8");
        if (tipo === "puestos" || !tipo) fs.writeFileSync(JSON_PUESTOS_FILE, JSON.stringify(memoryStorePuestos, null, 2), "utf-8");
        if (tipo === "postulaciones" || !tipo) fs.writeFileSync(JSON_POSTULACIONES_FILE, JSON.stringify(memoryStorePostulaciones, null, 2), "utf-8");
        if (tipo === "informes" || !tipo) fs.writeFileSync(JSON_INFORMES_FILE, JSON.stringify(memoryStoreInformes, null, 2), "utf-8");
        if (tipo === "usuarios" || !tipo) fs.writeFileSync(JSON_USUARIOS_FILE, JSON.stringify(memoryStoreUsuarios, null, 2), "utf-8");
        if (tipo === "areas" || !tipo) fs.writeFileSync(JSON_AREAS_FILE, JSON.stringify(memoryStoreAreas, null, 2), "utf-8");
        if (tipo === "etiquetas" || !tipo) fs.writeFileSync(JSON_ETIQUETAS_FILE, JSON.stringify(memoryStoreEtiquetas, null, 2), "utf-8");
    } catch {
        // Ignorar
    }
}

async function poblarSemillasMongo() {
    const countCandidatos = await CandidatoModel.countDocuments();
    if (countCandidatos === 0) {
        await CandidatoModel.insertMany(CANDIDATOS_SEED);
    }

    const countPuestos = await PuestoTrabajoModel.countDocuments();
    if (countPuestos === 0) {
        await PuestoTrabajoModel.insertMany(PUESTOS_SEED);
    }

    const countPostulaciones = await PostulacionModel.countDocuments();
    if (countPostulaciones === 0) {
        await PostulacionModel.insertMany(POSTULACIONES_SEED);
    } else {
        for (const posSeed of POSTULACIONES_SEED) {
            const existe = await PostulacionModel.findOne({ id: posSeed.id });
            if (!existe) {
                await PostulacionModel.create(posSeed);
            }
        }
    }

    const countInformes = await SolicitudInformeModel.countDocuments();
    if (countInformes === 0) {
        await SolicitudInformeModel.insertMany(INFORMES_SEED);
    } else {
        // Sincronizar preguntas y preguntasJefatura en documentos existentes en MongoDB
        const docsInformes = await SolicitudInformeModel.find();
        for (const doc of docsInformes) {
            const obj = doc.toJSON();
            const listaPreguntas =
                Array.isArray(obj.preguntasJefatura) && obj.preguntasJefatura.length > 0
                    ? obj.preguntasJefatura
                    : Array.isArray(obj.preguntas)
                    ? obj.preguntas
                    : [];
            if (
                !Array.isArray(obj.preguntas) ||
                !Array.isArray(obj.preguntasJefatura) ||
                obj.preguntas.length !== listaPreguntas.length ||
                obj.preguntasJefatura.length !== listaPreguntas.length
            ) {
                await SolicitudInformeModel.updateOne(
                    { id: obj.id },
                    { $set: { preguntas: listaPreguntas, preguntasJefatura: listaPreguntas } }
                );
            }
        }
    }

    const countEtiquetas = await EtiquetaModel.countDocuments();
    if (countEtiquetas === 0) {
        await EtiquetaModel.insertMany(ETIQUETAS_SEED);
    }

    const countUsuarios = await UsuarioModel.countDocuments();
    if (countUsuarios === 0) {
        await UsuarioModel.insertMany(USUARIOS_SEED);
    } else {
        // Garantizar que los 10 postulantes semilla tengan su cuenta de usuario
        for (const uSeed of USUARIOS_SEED) {
            const existe = await UsuarioModel.findOne({ email: uSeed.email.toLowerCase() });
            if (!existe) {
                await UsuarioModel.create(uSeed);
            }
        }
    }

    const countAreas = await AreaTrabajoModel.countDocuments();
    if (countAreas === 0) {
        await AreaTrabajoModel.insertMany(AREAS_SEED);
    }
}

// Inicializar conexión a MongoDB (con fallback inmediato si mongod no responde)
inicializarFallbackJson();

try {
    await mongoose.connect(MONGODB_URI, {
        serverSelectionTimeoutMS: 2500,
    });
    useMongo = true;
    await poblarSemillasMongo();
} catch (err) {
    useMongo = false;
    console.warn(`⚠️ MongoDB no disponible en ${MONGODB_URI} (${err.message}). Operando con respaldo local JSON.`);
}

async function siguienteIdMongo(Modelo, fallbackArray) {
    if (useMongo) {
        const ultimo = await Modelo.findOne().sort({ id: -1 }).lean();
        return ultimo && ultimo.id ? Number(ultimo.id) + 1 : 1;
    }
    return fallbackArray && fallbackArray.length > 0
        ? Math.max(...fallbackArray.map((item) => Number(item.id) || 0)) + 1
        : 1;
}

export const db = {
    isUsingMongo() {
        return useMongo && mongoose.connection.readyState === 1;
    },

    getMongoUri() {
        return MONGODB_URI;
    },

    getDbFilePath() {
        return this.isUsingMongo() ? MONGODB_URI : JSON_CANDIDATOS_FILE;
    },

    // ==================== CANDIDATOS / POSTULANTES (A2) ====================
    async obtenerTodos() {
        if (this.isUsingMongo()) {
            const docs = await CandidatoModel.find().sort({ id: -1 });
            return docs.map((d) => d.toJSON());
        }
        return [...memoryStoreCandidatos];
    },

    async obtenerPorId(id) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            const doc = await CandidatoModel.findOne({ id: numId });
            return doc ? doc.toJSON() : null;
        }
        return memoryStoreCandidatos.find((c) => Number(c.id) === numId) || null;
    },

    async buscarPorRut(rut) {
        if (!rut) return null;
        const rutObjetivo = limpiarRut(rut);

        if (this.isUsingMongo()) {
            const todos = await CandidatoModel.find();
            const encontrado = todos.find((c) => limpiarRut(c.rut) === rutObjetivo);
            return encontrado ? encontrado.toJSON() : null;
        }

        return memoryStoreCandidatos.find((c) => limpiarRut(c.rut) === rutObjetivo) || null;
    },

    async insertarCandidato(datos) {
        const fecha = datos.fecha ? new Date(datos.fecha).toISOString() : new Date().toISOString();
        const antecedentes = datos.antecedentes?.trim() || "";
        const infoMedica = datos.infoMedica?.trim() || "";
        const experienciaLaboral = datos.experienciaLaboral?.trim() || "";
        const email = datos.email?.trim().toLowerCase() || "";
        const telefono = datos.telefono?.trim() || "";
        const resultadoPsicologico = datos.resultadoPsicologico || "Pendiente";
        const evaluador = datos.evaluador?.trim() || "Sin Asignar";
        const estado = datos.estado?.trim() || "Pendiente";
        const cargo = datos.cargo?.trim() || "Postulante General";
        const familiaCargo = datos.familiaCargo?.trim() || "Operaciones Productivas";
        const planta = datos.planta?.trim() || null;

        const nombres =
            datos.nombres?.trim() ||
            (datos.nombre
                ? datos.nombre.split(" ").slice(0, -2).join(" ") || datos.nombre.split(" ")[0]
                : "");
        const apellidos =
            datos.apellidos?.trim() ||
            (datos.nombre ? datos.nombre.split(" ").slice(-2).join(" ") : "");
        const nombre = datos.nombre?.trim() || `${nombres} ${apellidos}`.trim() || "Postulante";
        const direccion = datos.direccion?.trim() || "";
        const comuna = datos.comuna?.trim() || "";
        const fecha_nacimiento = datos.fecha_nacimiento || "";
        const cv_pdf = datos.cv_pdf?.trim() || "";
        const cvDataUrl = datos.cvDataUrl || "";

        const nuevoId = await siguienteIdMongo(CandidatoModel, memoryStoreCandidatos);

        const nuevoCandidato = {
            id: nuevoId,
            nombre,
            nombres,
            apellidos,
            rut: datos.rut.trim(),
            direccion,
            comuna,
            fecha_nacimiento,
            cv_pdf,
            cvDataUrl,
            email,
            telefono,
            especialidad: (datos.especialidad || cargo).trim(),
            planta,
            cargo,
            familiaCargo,
            fecha,
            evaluador,
            estado,
            antecedentes,
            infoMedica,
            experienciaLaboral,
            resultadoPsicologico,
            fechaEvaluacion: datos.fechaEvaluacion || null,
            conclusiones: datos.conclusiones || null,
            fortalezas: Array.isArray(datos.fortalezas) ? datos.fortalezas : [],
            debilidades: Array.isArray(datos.debilidades) ? datos.debilidades : [],
            historial: Array.isArray(datos.historial) ? datos.historial : [],
        };

        if (this.isUsingMongo()) {
            const creado = await CandidatoModel.create(nuevoCandidato);
            return creado.toJSON();
        }

        memoryStoreCandidatos.unshift(nuevoCandidato);
        persistJson("candidatos");
        return nuevoCandidato;
    },

    async actualizarCandidato(id, datosActualizados) {
        const numId = Number(id);
        const camposValidos = [
            "nombre", "nombres", "apellidos", "rut", "direccion", "comuna",
            "fecha_nacimiento", "cv_pdf", "cvDataUrl", "email", "telefono",
            "especialidad", "planta", "cargo", "familiaCargo", "evaluador",
            "estado", "antecedentes", "infoMedica", "experienciaLaboral",
            "resultadoPsicologico", "fechaEvaluacion", "conclusiones",
            "fortalezas", "debilidades", "historial",
        ];

        const payload = {};
        for (const campo of camposValidos) {
            if (datosActualizados[campo] !== undefined) {
                payload[campo] = datosActualizados[campo];
            }
        }

        if (this.isUsingMongo()) {
            const doc = await CandidatoModel.findOneAndUpdate(
                { id: numId },
                { $set: payload },
                { new: true }
            );
            return doc ? doc.toJSON() : null;
        }

        const idx = memoryStoreCandidatos.findIndex((c) => Number(c.id) === numId);
        if (idx !== -1) {
            memoryStoreCandidatos[idx] = { ...memoryStoreCandidatos[idx], ...payload, id: numId };
            persistJson("candidatos");
            return memoryStoreCandidatos[idx];
        }
        return null;
    },

    async eliminarCandidato(id) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            const res = await CandidatoModel.deleteOne({ id: numId });
            return res.deletedCount > 0;
        }

        const idx = memoryStoreCandidatos.findIndex((c) => Number(c.id) === numId);
        if (idx === -1) return false;
        memoryStoreCandidatos.splice(idx, 1);
        persistJson("candidatos");
        return true;
    },

    // ==================== ÁREAS DE TRABAJO ====================
    async obtenerAreas({ busqueda } = {}) {
        let lista = [];
        if (this.isUsingMongo()) {
            const docs = await AreaTrabajoModel.find().sort({ id: 1 });
            lista = docs.map((d) => d.toJSON());
        } else {
            lista = [...(memoryStoreAreas || [])];
        }

        const termino = busqueda ? busqueda.toLowerCase().trim() : "";
        if (!termino) return lista;

        return lista.filter((a) => (a.tipo_area || "").toLowerCase().includes(termino));
    },

    async obtenerAreaPorId(id) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            const doc = await AreaTrabajoModel.findOne({ id: numId });
            return doc ? doc.toJSON() : null;
        }
        return (memoryStoreAreas || []).find((a) => Number(a.id) === numId) || null;
    },

    // ==================== PUESTOS DE TRABAJO (Ofertas Laborales) ====================
    async obtenerPuestos({ busqueda, planta, familiaCargo, estado, areaId } = {}) {
        let lista = [];
        if (this.isUsingMongo()) {
            const docs = await PuestoTrabajoModel.find().sort({ id: -1 });
            lista = docs.map((d) => d.toJSON());
        } else {
            lista = [...(memoryStorePuestos || [])];
        }

        return lista.filter((p) => {
            const termino = busqueda ? busqueda.toLowerCase().trim() : "";
            const coincideTexto =
                !termino ||
                p.titulo.toLowerCase().includes(termino) ||
                (p.descripcion && p.descripcion.toLowerCase().includes(termino)) ||
                (p.requisitos && p.requisitos.toLowerCase().includes(termino));

            const coincidePlanta =
                !planta ||
                planta === "todas" ||
                p.planta.toLowerCase() === planta.toLowerCase();

            const coincideFamilia =
                !familiaCargo ||
                familiaCargo === "todas" ||
                p.familiaCargo.toLowerCase() === familiaCargo.toLowerCase();

            const coincideEstado =
                !estado ||
                estado === "todos" ||
                p.estado.toLowerCase() === estado.toLowerCase();

            const coincideArea =
                areaId === undefined ||
                areaId === null ||
                areaId === "" ||
                areaId === "todas" ||
                Number(p.area_id) === Number(areaId);

            return coincideTexto && coincidePlanta && coincideFamilia && coincideEstado && coincideArea;
        });
    },

    async obtenerPuestoPorId(id) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            const doc = await PuestoTrabajoModel.findOne({ id: numId });
            return doc ? doc.toJSON() : null;
        }
        return (memoryStorePuestos || []).find((p) => Number(p.id) === numId) || null;
    },

    async insertarPuesto(datos) {
        const fechaCreacion = datos.fechaCreacion || new Date().toISOString();
        const vacantes = Number(datos.vacantes) || 1;
        const estado = datos.estado || "Abierto";
        const creadoPor = datos.creadoPor || "Jefe de Área";
        const area_id =
            datos.area_id === undefined || datos.area_id === null || datos.area_id === ""
                ? null
                : Number(datos.area_id);
        const nuevoId = await siguienteIdMongo(PuestoTrabajoModel, memoryStorePuestos);

        const etiquetas = Array.isArray(datos.etiquetas)
            ? datos.etiquetas.map((t) => String(t).trim()).filter(Boolean)
            : [];

        // Asegurar que las etiquetas queden guardadas en el catálogo global
        for (const tag of etiquetas) {
            await this.insertarEtiqueta(tag);
        }

        const nuevoPuesto = {
            id: nuevoId,
            area_id,
            titulo: datos.titulo.trim(),
            planta: datos.planta.trim(),
            familiaCargo: datos.familiaCargo.trim(),
            descripcion: datos.descripcion?.trim() || "",
            requisitos: datos.requisitos?.trim() || "",
            etiquetas,
            vacantes,
            estado,
            creadoPor,
            fechaCreacion,
            conteoModificaciones: 0,
            historialModificaciones: [],
        };

        if (this.isUsingMongo()) {
            const creado = await PuestoTrabajoModel.create(nuevoPuesto);
            return creado.toJSON();
        }

        if (!memoryStorePuestos) memoryStorePuestos = [];
        memoryStorePuestos.unshift(nuevoPuesto);
        persistJson("puestos");
        return nuevoPuesto;
    },

    async actualizarPuesto(id, datos) {
        const numId = Number(id);
        const previo = await this.obtenerPuestoPorId(numId);
        if (!previo) return null;

        const camposPermitidos = [
            "area_id",
            "titulo",
            "planta",
            "familiaCargo",
            "descripcion",
            "requisitos",
            "etiquetas",
            "vacantes",
            "estado",
        ];
        const payload = {};
        for (const campo of camposPermitidos) {
            if (datos[campo] !== undefined) {
                if (campo === "vacantes") {
                    payload[campo] = Number(datos[campo]);
                } else if (campo === "area_id") {
                    payload[campo] =
                        datos[campo] === null || datos[campo] === ""
                            ? null
                            : Number(datos[campo]);
                } else if (campo === "etiquetas") {
                    payload[campo] = Array.isArray(datos[campo])
                        ? datos[campo].map((t) => String(t).trim()).filter(Boolean)
                        : [];
                    for (const tag of payload[campo]) {
                        await this.insertarEtiqueta(tag);
                    }
                } else {
                    payload[campo] = datos[campo];
                }
            }
        }

        // Registrar conteo e historial de modificaciones si cambiaron condiciones del trabajo
        const cambiosDetectados = [];
        if (payload.titulo !== undefined && payload.titulo !== previo.titulo) {
            cambiosDetectados.push(`Título: "${previo.titulo}" → "${payload.titulo}"`);
        }
        if (payload.planta !== undefined && payload.planta !== previo.planta) {
            cambiosDetectados.push(`Planta: ${previo.planta} → ${payload.planta}`);
        }
        if (payload.vacantes !== undefined && Number(payload.vacantes) !== Number(previo.vacantes)) {
            cambiosDetectados.push(`Vacantes: ${previo.vacantes} → ${payload.vacantes}`);
        }
        if (payload.descripcion !== undefined && payload.descripcion !== previo.descripcion) {
            cambiosDetectados.push("Descripción actualizada");
        }
        if (payload.requisitos !== undefined && payload.requisitos !== previo.requisitos) {
            cambiosDetectados.push("Requisitos actualizados");
        }
        if (payload.estado !== undefined && payload.estado !== previo.estado) {
            cambiosDetectados.push(`Estado: ${previo.estado} → ${payload.estado}`);
        }
        if (
            payload.etiquetas !== undefined &&
            JSON.stringify(payload.etiquetas) !== JSON.stringify(previo.etiquetas || [])
        ) {
            cambiosDetectados.push("Cualidades/etiquetas actualizadas");
        }

        if (cambiosDetectados.length > 0 || datos.detalleModificacion) {
            const historialActual = Array.isArray(previo.historialModificaciones)
                ? previo.historialModificaciones
                : [];
            const nuevoRegistroHistorial = {
                fecha: new Date().toISOString(),
                autor: datos.modificadoPor || previo.creadoPor || "Jefe de Área",
                detalle: datos.detalleModificacion || cambiosDetectados.join(" · "),
            };
            payload.historialModificaciones = [nuevoRegistroHistorial, ...historialActual];
            payload.conteoModificaciones = (Number(previo.conteoModificaciones) || historialActual.length) + 1;
        }

        if (this.isUsingMongo()) {
            const doc = await PuestoTrabajoModel.findOneAndUpdate(
                { id: numId },
                { $set: payload },
                { new: true }
            );
            return doc ? doc.toJSON() : null;
        }

        const idx = (memoryStorePuestos || []).findIndex((p) => Number(p.id) === numId);
        if (idx !== -1) {
            memoryStorePuestos[idx] = { ...memoryStorePuestos[idx], ...payload, id: numId };
            persistJson("puestos");
            return memoryStorePuestos[idx];
        }
        return null;
    },

    async eliminarPuesto(id) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            const res = await PuestoTrabajoModel.deleteOne({ id: numId });
            return res.deletedCount > 0;
        }

        const idx = (memoryStorePuestos || []).findIndex((p) => Number(p.id) === numId);
        if (idx === -1) return false;
        memoryStorePuestos.splice(idx, 1);
        persistJson("puestos");
        return true;
    },

    // ==================== POSTULACIONES ====================
    async obtenerPostulaciones({ candidatoId, puestoTrabajoId, estado, evaluador, areaId } = {}) {
        let postulacionesRaw = [];
        let candidatosRaw = [];
        let puestosRaw = [];

        if (this.isUsingMongo()) {
            const [posDocs, candDocs, puesDocs] = await Promise.all([
                PostulacionModel.find().sort({ id: -1 }),
                CandidatoModel.find(),
                PuestoTrabajoModel.find(),
            ]);
            postulacionesRaw = posDocs.map((d) => d.toJSON());
            candidatosRaw = candDocs.map((d) => d.toJSON());
            puestosRaw = puesDocs.map((d) => d.toJSON());
        } else {
            postulacionesRaw = [...(memoryStorePostulaciones || [])];
            candidatosRaw = [...(memoryStoreCandidatos || [])];
            puestosRaw = [...(memoryStorePuestos || [])];
        }

        const lista = postulacionesRaw.map((pos) => {
            const c = candidatosRaw.find((item) => Number(item.id) === Number(pos.candidatoId));
            const p = puestosRaw.find((item) => Number(item.id) === Number(pos.puestoTrabajoId));
            const dictamenFinal =
                pos.dictamenPsicologico && pos.dictamenPsicologico !== "Pendiente"
                    ? pos.dictamenPsicologico
                    : c?.resultadoPsicologico || "Pendiente";
            return {
                ...pos,
                puestoId: pos.puestoTrabajoId,
                puestoTrabajoId: pos.puestoTrabajoId,
                candidatoNombre: c?.nombre,
                nombreCandidato: c?.nombre,
                nombre: c?.nombre,
                nombres: c?.nombres,
                apellidos: c?.apellidos,
                candidatoRut: c?.rut,
                rutCandidato: c?.rut,
                rut: c?.rut,
                candidatoEmail: c?.email,
                email: c?.email,
                candidatoTelefono: c?.telefono,
                telefono: c?.telefono,
                direccion: c?.direccion,
                comuna: c?.comuna || p?.planta || c?.planta,
                fecha_nacimiento: c?.fecha_nacimiento,
                cv_pdf: c?.cv_pdf,
                cvArchivo: c?.cv_pdf,
                cvDataUrl: c?.cvDataUrl,
                candidatoEspecialidad: c?.especialidad,
                especialidad: c?.especialidad,
                candidatoInfoMedica: c?.infoMedica,
                infoMedica: c?.infoMedica,
                candidatoExperiencia: c?.experienciaLaboral,
                experienciaLaboral: c?.experienciaLaboral,
                antecedentes: c?.antecedentes,
                resultadoPsicologico: dictamenFinal,
                dictamenPsicologico: dictamenFinal,
                fechaEvaluacion: c?.fechaEvaluacion,
                conclusiones: pos.conclusiones || c?.conclusiones || null,
                fortalezas: c?.fortalezas || [],
                debilidades: c?.debilidades || [],
                historial: c?.historial || [],
                puestoTitulo: p?.titulo,
                cargo: p?.titulo || c?.cargo,
                puestoPlanta: p?.planta,
                planta: p?.planta || c?.planta,
                puestoFamilia: p?.familiaCargo,
                familiaCargo: p?.familiaCargo || c?.familiaCargo,
                area_id: p?.area_id || null,
                evaluador: pos.evaluadorAsignado || c?.evaluador,
                encargado: pos.evaluadorAsignado || c?.evaluador,
                fecha: pos.fechaPostulacion || c?.fecha,
            };
        });

        return lista.filter((pos) => {
            const coincideCandidato = !candidatoId || Number(pos.candidatoId) === Number(candidatoId);
            const coincidePuesto = !puestoTrabajoId || Number(pos.puestoTrabajoId) === Number(puestoTrabajoId);
            const coincideEstado = !estado || estado === "todos" || pos.estado.toLowerCase() === estado.toLowerCase();
            const coincideEvaluador =
                !evaluador ||
                evaluador === "todos" ||
                (pos.evaluadorAsignado && pos.evaluadorAsignado.toLowerCase() === evaluador.toLowerCase());
            const coincideArea = !areaId || Number(pos.area_id) === Number(areaId);

            return coincideCandidato && coincidePuesto && coincideEstado && coincideEvaluador && coincideArea;
        });
    },

    async obtenerPostulacionPorId(id) {
        const numId = Number(id);
        const lista = await this.obtenerPostulaciones();
        return lista.find((p) => Number(p.id) === numId) || null;
    },

    async insertarPostulacion(datos) {
        const candidatoId = Number(datos.candidatoId);
        const puestoTrabajoId = Number(datos.puestoTrabajoId);

        const existentes = await this.obtenerPostulaciones({ candidatoId, puestoTrabajoId });
        const yaPostulado = existentes.some((p) => p.estado !== "Finalizado");
        if (yaPostulado) {
            const error = new Error("El candidato ya tiene una postulación activa para este puesto de trabajo.");
            error.codigo = "POSTULACION_DUPLICADA";
            throw error;
        }

        const fechaPostulacion = datos.fechaPostulacion || new Date().toISOString();
        const estado = datos.estado || "Postulado";
        const evaluadorAsignado = datos.evaluadorAsignado || "Sin Asignar";
        const nuevoId = await siguienteIdMongo(PostulacionModel, memoryStorePostulaciones);

        const nuevaPos = {
            id: nuevoId,
            candidatoId,
            puestoTrabajoId,
            estado,
            fechaPostulacion,
            evaluadorAsignado,
            fechaEntrevista: null,
            respuestaCandidato: "Pendiente",
            sugerenciaFecha: null,
            dictamenPsicologico: "Pendiente",
            observaciones: "",
            conclusiones: "",
            decisionFinal: "Pendiente",
        };

        if (this.isUsingMongo()) {
            await PostulacionModel.create(nuevaPos);
            return this.obtenerPostulacionPorId(nuevoId);
        }

        if (!memoryStorePostulaciones) memoryStorePostulaciones = [];
        memoryStorePostulaciones.unshift(nuevaPos);
        persistJson("postulaciones");
        return this.obtenerPostulacionPorId(nuevoId);
    },

    async actualizarPostulacion(id, datos) {
        const numId = Number(id);
        const camposPermitidos = [
            "estado", "evaluadorAsignado", "fechaEntrevista", "tipoCitacion",
            "enlaceGoogleMeet", "urlGoogleCalendar", "respuestaCandidato",
            "sugerenciaFecha", "dictamenPsicologico", "observaciones", "conclusiones",
            "decisionFinal",
        ];

        const payload = {};
        for (const campo of camposPermitidos) {
            if (datos[campo] !== undefined) {
                payload[campo] = datos[campo];
            }
        }

        if (this.isUsingMongo()) {
            const doc = await PostulacionModel.findOneAndUpdate(
                { id: numId },
                { $set: payload },
                { new: true }
            );
            if (!doc) return null;
            return this.obtenerPostulacionPorId(numId);
        }

        const idx = (memoryStorePostulaciones || []).findIndex((p) => Number(p.id) === numId);
        if (idx !== -1) {
            memoryStorePostulaciones[idx] = { ...memoryStorePostulaciones[idx], ...payload, id: numId };
            persistJson("postulaciones");
            return this.obtenerPostulacionPorId(numId);
        }
        return null;
    },

    // ==================== USUARIOS / AUTENTICACIÓN (B1 / B2) ====================
    async obtenerUsuarios() {
        if (this.isUsingMongo()) {
            const docs = await UsuarioModel.find().sort({ id: 1 });
            return docs.map((d) => {
                const { password: _, ...resto } = d.toJSON();
                return resto;
            });
        }
        return (memoryStoreUsuarios || []).map(({ password: _, ...u }) => u);
    },

    async obtenerUsuarioPorEmail(email) {
        if (!email) return null;
        const limpio = email.toLowerCase().trim();
        if (this.isUsingMongo()) {
            const doc = await UsuarioModel.findOne({ email: limpio });
            return doc ? doc.toJSON() : null;
        }
        return (memoryStoreUsuarios || []).find((u) => u.email.toLowerCase() === limpio) || null;
    },

    async obtenerUsuarioPorCandidatoId(candidatoId) {
        if (!candidatoId) return null;
        const numId = Number(candidatoId);
        if (this.isUsingMongo()) {
            const doc = await UsuarioModel.findOne({ candidatoId: numId });
            return doc ? doc.toJSON() : null;
        }
        return (memoryStoreUsuarios || []).find((u) => Number(u.candidatoId) === numId) || null;
    },

    async obtenerUsuarioPorId(id) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            const doc = await UsuarioModel.findOne({ id: numId });
            if (!doc) return null;
            const { password: _, ...resto } = doc.toJSON();
            return resto;
        }
        const u = (memoryStoreUsuarios || []).find((item) => Number(item.id) === numId);
        if (!u) return null;
        const { password: _, ...resto } = u;
        return resto;
    },

    async insertarUsuario(datos) {
        const email = datos.email.toLowerCase().trim();
        const existente = await this.obtenerUsuarioPorEmail(email);
        if (existente) {
            const error = new Error("El correo electrónico ya se encuentra registrado.");
            error.codigo = "EMAIL_DUPLICADO";
            throw error;
        }

        const rawPass = datos.password || "password123";
        let passwordHash = rawPass;
        if (!rawPass.startsWith("$2a$") && !rawPass.startsWith("$2b$")) {
            const salt = await bcrypt.genSalt(10);
            passwordHash = await bcrypt.hash(rawPass, salt);
        }

        const nombre = datos.nombre.trim();
        const rol = datos.rol || "candidato";
        const candidatoId = datos.candidatoId ? Number(datos.candidatoId) : null;
        const rawAreaId = datos.area_id !== undefined ? datos.area_id : datos.area;
        const area_id =
            rawAreaId === undefined || rawAreaId === null || rawAreaId === ""
                ? null
                : Number(rawAreaId);
        const nuevoId = await siguienteIdMongo(UsuarioModel, memoryStoreUsuarios);

        const nuevoUsuario = {
            id: nuevoId,
            email,
            password: passwordHash,
            nombre,
            rol,
            candidatoId,
            area_id,
        };

        if (this.isUsingMongo()) {
            const creado = await UsuarioModel.create(nuevoUsuario);
            const { password: _, ...sinPass } = creado.toJSON();
            return sinPass;
        }

        if (!memoryStoreUsuarios) memoryStoreUsuarios = [];
        memoryStoreUsuarios.push(nuevoUsuario);
        persistJson("usuarios");
        const { password: _, ...sinPass } = nuevoUsuario;
        return sinPass;
    },

    /**
     * Autentica un usuario permitiendo ingresar Email o RUT + Contraseña (B2).
     */
    async autenticarUsuario({ email, rut, identificador, password }) {
        const idInput = (identificador || email || rut || "").trim();
        if (!idInput || !password) return null;

        let user = await this.obtenerUsuarioPorEmail(idInput);

        // Si no se encontró por email, buscar si ingresó su RUT de postulante
        if (!user) {
            const candidatoPorRut = await this.buscarPorRut(idInput);
            if (candidatoPorRut) {
                user = await this.obtenerUsuarioPorCandidatoId(candidatoPorRut.id);
                if (!user && candidatoPorRut.email) {
                    user = await this.obtenerUsuarioPorEmail(candidatoPorRut.email);
                }
            }
        }

        if (!user) return null;

        let passwordValida = false;
        if (user.password && (user.password.startsWith("$2a$") || user.password.startsWith("$2b$"))) {
            passwordValida = await bcrypt.compare(password, user.password);
        } else {
            // Compatibilidad con usuarios de demostración históricos y auto-migración a bcrypt
            passwordValida = user.password === password;
            if (passwordValida && user.id) {
                try {
                    const salt = await bcrypt.genSalt(10);
                    const nuevoHash = await bcrypt.hash(password, salt);
                    await this.actualizarPasswordUsuario(user.id, nuevoHash);
                } catch (e) {
                    console.warn("No se pudo auto-migrar contraseña a bcrypt:", e.message);
                }
            }
        }

        if (!passwordValida) return null;

        const { password: _, ...usuarioAutenticado } = user;
        return usuarioAutenticado;
    },

    async actualizarPasswordUsuario(id, nuevoHash) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            await UsuarioModel.updateOne({ id: numId }, { $set: { password: nuevoHash } });
            return true;
        }
        const idx = (memoryStoreUsuarios || []).findIndex((u) => Number(u.id) === numId);
        if (idx !== -1) {
            memoryStoreUsuarios[idx].password = nuevoHash;
            persistJson("usuarios");
            return true;
        }
        return false;
    },

    // ==================== SOLICITUDES DE INFORME ====================
    _normalizarInforme(inf) {
        if (!inf) return null;
        const listaPreguntas =
            Array.isArray(inf.preguntasJefatura) && inf.preguntasJefatura.length > 0
                ? inf.preguntasJefatura
                : Array.isArray(inf.preguntas)
                ? inf.preguntas
                : [];
        return {
            ...inf,
            tipo: inf.tipo || "candidato",
            solicitante: inf.solicitante || "Jefe de Área",
            urgencia: inf.urgencia || "Media",
            fechaLimite: inf.fechaLimite || null,
            dictamen: inf.dictamen || "Pendiente",
            fortalezas: Array.isArray(inf.fortalezas) ? inf.fortalezas : [],
            debilidades: Array.isArray(inf.debilidades) ? inf.debilidades : [],
            historial: Array.isArray(inf.historial) ? inf.historial : [],
            destinatarios: Array.isArray(inf.destinatarios) ? inf.destinatarios : ["analista", "evaluador"],
            preguntas: listaPreguntas,
            preguntasJefatura: listaPreguntas,
        };
    },

    async obtenerSolicitudesInforme({ busqueda, estado, candidatoId, puestoTrabajoId, postulacionId, urgencia, tipo, areaId } = {}) {
        let lista = [];
        let puestosRaw = [];
        if (this.isUsingMongo()) {
            const [docs, pDocs] = await Promise.all([
                SolicitudInformeModel.find().sort({ id: -1 }),
                areaId ? PuestoTrabajoModel.find() : Promise.resolve([]),
            ]);
            lista = docs.map((d) => this._normalizarInforme(d.toJSON()));
            puestosRaw = pDocs.map((d) => d.toJSON());
        } else {
            lista = [...(memoryStoreInformes || [])].map((inf) => this._normalizarInforme(inf));
            puestosRaw = [...(memoryStorePuestos || [])];
        }

        return lista.filter((inf) => {
            const termino = busqueda ? busqueda.toLowerCase().trim() : "";
            const coincideTexto =
                !termino ||
                inf.candidatoNombre?.toLowerCase().includes(termino) ||
                inf.solicitante?.toLowerCase().includes(termino) ||
                inf.evaluador?.toLowerCase().includes(termino) ||
                inf.preguntasJefatura?.some((p) => p.texto?.toLowerCase().includes(termino));

            const coincideEstado =
                !estado ||
                estado === "todos" ||
                inf.estado?.toLowerCase() === estado.toLowerCase();

            const coincideCandidato =
                !candidatoId ||
                Number(inf.candidatoId) === Number(candidatoId);

            const coincidePuesto =
                !puestoTrabajoId ||
                Number(inf.puestoTrabajoId) === Number(puestoTrabajoId);

            const coincidePostulacion =
                !postulacionId ||
                Number(inf.postulacionId) === Number(postulacionId);

            const coincideUrgencia =
                !urgencia ||
                urgencia === "todas" ||
                inf.urgencia?.toLowerCase() === urgencia.toLowerCase();

            const coincideTipo =
                !tipo ||
                tipo === "todos" ||
                inf.tipo?.toLowerCase() === tipo.toLowerCase();

            const puestoAsociado = areaId ? puestosRaw.find((p) => Number(p.id) === Number(inf.puestoTrabajoId)) : null;
            const coincideArea = !areaId || Number(puestoAsociado?.area_id) === Number(areaId);

            return (
                coincideTexto &&
                coincideEstado &&
                coincideCandidato &&
                coincidePuesto &&
                coincidePostulacion &&
                coincideUrgencia &&
                coincideTipo &&
                coincideArea
            );
        });
    },

    async obtenerSolicitudInformePorId(id) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            const doc = await SolicitudInformeModel.findOne({ id: numId });
            return doc ? this._normalizarInforme(doc.toJSON()) : null;
        }
        const encontrado = (memoryStoreInformes || []).find((i) => Number(i.id) === numId);
        return encontrado ? this._normalizarInforme(encontrado) : null;
    },

    async insertarSolicitudInforme(datos) {
        const candidato = datos.candidatoId ? await this.obtenerPorId(datos.candidatoId) : null;
        const candidatoNombre = datos.candidatoNombre || candidato?.nombre || null;
        const fechaCreacion = datos.fechaCreacion || new Date().toISOString();
        const puestoTrabajoId = datos.puestoTrabajoId ? Number(datos.puestoTrabajoId) : null;
        const solicitante = datos.solicitante?.trim() || "Jefe de Área";
        const urgencia = datos.urgencia || "Media";
        const fechaLimite = datos.fechaLimite || null;
        const tipo = datos.tipo || (puestoTrabajoId && !datos.candidatoId ? "puesto" : "candidato");
        const destinatarios = Array.isArray(datos.destinatarios) ? datos.destinatarios : ["analista", "evaluador"];

        const rawPreguntas = Array.isArray(datos.preguntasJefatura) && datos.preguntasJefatura.length > 0
            ? datos.preguntasJefatura
            : Array.isArray(datos.preguntas)
            ? datos.preguntas
            : [];

        const preguntasNormalizadas = rawPreguntas.map((p, index) => {
            if (typeof p === "string") {
                return {
                    id: index + 1,
                    texto: p.trim(),
                    fecha: fechaCreacion,
                    creadaPor: solicitante,
                    respuestas: [],
                };
            }
            return {
                id: p.id || index + 1,
                texto: p.texto?.trim() || "",
                fecha: p.fecha || fechaCreacion,
                creadaPor: p.creadaPor || solicitante,
                respuestas: Array.isArray(p.respuestas) ? p.respuestas : [],
            };
        });

        const nuevoId = await siguienteIdMongo(SolicitudInformeModel, memoryStoreInformes);

        const nuevoInforme = {
            id: nuevoId,
            postulacionId: datos.postulacionId ? Number(datos.postulacionId) : null,
            candidatoId: datos.candidatoId ? Number(datos.candidatoId) : null,
            candidatoNombre,
            puestoTrabajoId,
            tipo,
            solicitante,
            urgencia,
            fechaLimite,
            // Evaluación técnica (vacía al inicio, la llena el evaluador)
            evaluador: datos.evaluador || candidato?.evaluador || null,
            fechaEvaluacion: datos.fechaEvaluacion || null,
            dictamen: datos.dictamen || "Pendiente",
            conclusiones: datos.conclusiones || null,
            fortalezas: Array.isArray(datos.fortalezas) ? datos.fortalezas : [],
            debilidades: Array.isArray(datos.debilidades) ? datos.debilidades : [],
            historial: Array.isArray(datos.historial) ? datos.historial : [
                {
                    fecha: fechaCreacion,
                    accion: "Informe creado",
                    autor: solicitante || "Sistema",
                    rol: datos.solicitante ? "jefatura" : "sistema",
                    detalle: "Generación del informe psicolaboral.",
                },
            ],
            // Metadatos
            estado: datos.estado || "Abierta",
            fechaCreacion,
            destinatarios,
            // Preguntas de jefatura (embebidas y sincronizadas)
            preguntas: preguntasNormalizadas,
            preguntasJefatura: preguntasNormalizadas,
        };

        if (this.isUsingMongo()) {
            const creado = await SolicitudInformeModel.create(nuevoInforme);
            return this._normalizarInforme(creado.toJSON());
        }

        if (!memoryStoreInformes) memoryStoreInformes = [];
        memoryStoreInformes.unshift(nuevoInforme);
        persistJson("informes");
        return this._normalizarInforme(nuevoInforme);
    },

    async agregarPreguntaInforme(id, { texto, creadaPor }) {
        const numId = Number(id);
        const informe = await this.obtenerSolicitudInformePorId(numId);
        if (!informe) return null;

        // Informe cerrado: rechazar (la validación también está en el controlador)
        if (informe.estado === "Cerrado" || informe.estado === "Cerrada") return informe;

        const nuevaPregunta = {
            id: Date.now(),
            texto: texto.trim(),
            fecha: new Date().toISOString(),
            creadaPor: creadaPor || "Jefe de Área",
            respuestas: [],
        };

        const preguntasBase =
            Array.isArray(informe.preguntasJefatura) && informe.preguntasJefatura.length > 0
                ? informe.preguntasJefatura
                : Array.isArray(informe.preguntas)
                ? informe.preguntas
                : [];
        const preguntasActualizadas = [...preguntasBase, nuevaPregunta];

        if (this.isUsingMongo()) {
            const doc = await SolicitudInformeModel.findOneAndUpdate(
                { id: numId },
                { $set: { preguntas: preguntasActualizadas, preguntasJefatura: preguntasActualizadas } },
                { new: true }
            );
            return doc ? this._normalizarInforme(doc.toJSON()) : null;
        }

        const idx = (memoryStoreInformes || []).findIndex((i) => Number(i.id) === numId);
        if (idx !== -1) {
            memoryStoreInformes[idx].preguntas = preguntasActualizadas;
            memoryStoreInformes[idx].preguntasJefatura = preguntasActualizadas;
            persistJson("informes");
            return this._normalizarInforme(memoryStoreInformes[idx]);
        }
        return null;
    },

    async actualizarDictamenInforme(id, { evaluador, fechaEvaluacion, dictamen, conclusiones, fortalezas, debilidades, historialItem }) {
        const numId = Number(id);
        const informePrevio = await this.obtenerSolicitudInformePorId(numId);
        const payload = {};
        if (evaluador !== undefined) payload.evaluador = evaluador;
        if (fechaEvaluacion !== undefined) payload.fechaEvaluacion = fechaEvaluacion;
        if (dictamen !== undefined) payload.dictamen = dictamen;
        if (conclusiones !== undefined) payload.conclusiones = conclusiones;
        if (fortalezas !== undefined) payload.fortalezas = fortalezas;
        if (debilidades !== undefined) payload.debilidades = debilidades;

        // Historial acumulativo
        const historialPrevio = Array.isArray(informePrevio?.historial) ? informePrevio.historial : [];
        if (historialItem) {
            payload.historial = [...historialPrevio, {
                fecha: new Date().toISOString(),
                ...historialItem,
            }];
        }

        if (this.isUsingMongo()) {
            const doc = await SolicitudInformeModel.findOneAndUpdate(
                { id: numId },
                { $set: payload },
                { new: true }
            );
            if (doc) {
                if (doc.candidatoId) {
                    const cUpd = {};
                    if (payload.dictamen) cUpd.resultadoPsicologico = payload.dictamen;
                    if (payload.fechaEvaluacion) cUpd.fechaEvaluacion = payload.fechaEvaluacion;
                    if (payload.conclusiones !== undefined) cUpd.conclusiones = payload.conclusiones;
                    if (payload.fortalezas !== undefined) cUpd.fortalezas = payload.fortalezas;
                    if (payload.debilidades !== undefined) cUpd.debilidades = payload.debilidades;
                    if (Object.keys(cUpd).length > 0) {
                        await CandidatoModel.findOneAndUpdate({ id: doc.candidatoId }, { $set: cUpd });
                    }
                }
                if (doc.postulacionId) {
                    const pUpd = {};
                    if (payload.dictamen) pUpd.dictamenPsicologico = payload.dictamen;
                    if (payload.conclusiones !== undefined) pUpd.conclusiones = payload.conclusiones;
                    if (Object.keys(pUpd).length > 0) {
                        await PostulacionModel.findOneAndUpdate({ id: doc.postulacionId }, { $set: pUpd });
                    }
                }
            }
            return doc ? this._normalizarInforme(doc.toJSON()) : null;
        }

        const idx = (memoryStoreInformes || []).findIndex((i) => Number(i.id) === numId);
        if (idx !== -1) {
            Object.assign(memoryStoreInformes[idx], payload);
            const inf = memoryStoreInformes[idx];
            if (inf.candidatoId) {
                const cIdx = memoryStoreCandidatos.findIndex((c) => Number(c.id) === Number(inf.candidatoId));
                if (cIdx !== -1) {
                    if (payload.dictamen) memoryStoreCandidatos[cIdx].resultadoPsicologico = payload.dictamen;
                    if (payload.fechaEvaluacion) memoryStoreCandidatos[cIdx].fechaEvaluacion = payload.fechaEvaluacion;
                    if (payload.conclusiones !== undefined) memoryStoreCandidatos[cIdx].conclusiones = payload.conclusiones;
                    if (payload.fortalezas !== undefined) memoryStoreCandidatos[cIdx].fortalezas = payload.fortalezas;
                    if (payload.debilidades !== undefined) memoryStoreCandidatos[cIdx].debilidades = payload.debilidades;
                    persistJson("candidatos");
                }
            }
            if (inf.postulacionId) {
                const pIdx = memoryStorePostulaciones.findIndex((p) => Number(p.id) === Number(inf.postulacionId));
                if (pIdx !== -1) {
                    if (payload.dictamen) memoryStorePostulaciones[pIdx].dictamenPsicologico = payload.dictamen;
                    if (payload.conclusiones !== undefined) memoryStorePostulaciones[pIdx].conclusiones = payload.conclusiones;
                    persistJson("postulaciones");
                }
            }
            persistJson("informes");
            return this._normalizarInforme(memoryStoreInformes[idx]);
        }
        return null;
    },

    async sincronizarInformePorCandidato(candidatoId, payload) {
        const numCandId = Number(candidatoId);
        if (!numCandId) return;

        if (this.isUsingMongo()) {
            await SolicitudInformeModel.updateMany(
                { candidatoId: numCandId },
                { $set: payload }
            );
            return;
        }

        if (Array.isArray(memoryStoreInformes)) {
            for (const inf of memoryStoreInformes) {
                if (Number(inf.candidatoId) === numCandId) {
                    Object.assign(inf, payload);
                }
            }
            persistJson("informes");
        }
    },

    async agregarRespuestaInforme(id, preguntaId, { autor, rol, texto }) {
        const numId = Number(id);
        const numPreguntaId = Number(preguntaId);
        const informe = await this.obtenerSolicitudInformePorId(numId);
        if (!informe) return null;

        const nuevaRespuesta = {
            id: Date.now(),
            autor: autor || (rol === "evaluador" ? "Evaluador" : "Analista"),
            rol: rol || "evaluador",
            texto: texto.trim(),
            fecha: new Date().toISOString(),
        };

        const preguntasBase =
            Array.isArray(informe.preguntasJefatura) && informe.preguntasJefatura.length > 0
                ? informe.preguntasJefatura
                : Array.isArray(informe.preguntas)
                ? informe.preguntas
                : [];

        const preguntasActualizadas = preguntasBase.map((p) => {
            if (Number(p.id) === numPreguntaId) {
                return {
                    ...p,
                    respuestas: [...(p.respuestas || []), nuevaRespuesta],
                };
            }
            return p;
        });

        if (this.isUsingMongo()) {
            const doc = await SolicitudInformeModel.findOneAndUpdate(
                { id: numId },
                { $set: { preguntas: preguntasActualizadas, preguntasJefatura: preguntasActualizadas } },
                { new: true }
            );
            return doc ? this._normalizarInforme(doc.toJSON()) : null;
        }

        const idx = (memoryStoreInformes || []).findIndex((i) => Number(i.id) === numId);
        if (idx !== -1) {
            memoryStoreInformes[idx].preguntas = preguntasActualizadas;
            memoryStoreInformes[idx].preguntasJefatura = preguntasActualizadas;
            persistJson("informes");
            return this._normalizarInforme(memoryStoreInformes[idx]);
        }
        return null;
    },

    async actualizarEstadoSolicitudInforme(id, estado) {
        const numId = Number(id);
        if (this.isUsingMongo()) {
            const doc = await SolicitudInformeModel.findOneAndUpdate(
                { id: numId },
                { $set: { estado } },
                { new: true }
            );
            return doc ? this._normalizarInforme(doc.toJSON()) : null;
        }

        const idx = (memoryStoreInformes || []).findIndex((i) => Number(i.id) === numId);
        if (idx !== -1) {
            memoryStoreInformes[idx].estado = estado;
            persistJson("informes");
            return this._normalizarInforme(memoryStoreInformes[idx]);
        }
        return null;
    },

    // ==================== RESTABLECER DEMO ====================
    async restablecerDemo() {
        if (this.isUsingMongo()) {
            await Promise.all([
                CandidatoModel.deleteMany({}),
                PuestoTrabajoModel.deleteMany({}),
                PostulacionModel.deleteMany({}),
                SolicitudInformeModel.deleteMany({}),
                UsuarioModel.deleteMany({}),
                AreaTrabajoModel.deleteMany({}),
                EtiquetaModel.deleteMany({}),
            ]);

            await Promise.all([
                CandidatoModel.insertMany(CANDIDATOS_SEED),
                PuestoTrabajoModel.insertMany(PUESTOS_SEED),
                PostulacionModel.insertMany(POSTULACIONES_SEED),
                SolicitudInformeModel.insertMany(INFORMES_SEED),
                UsuarioModel.insertMany(USUARIOS_SEED),
                AreaTrabajoModel.insertMany(AREAS_SEED),
                EtiquetaModel.insertMany(ETIQUETAS_SEED),
            ]);

            return {
                totalCandidatos: CANDIDATOS_SEED.length,
                totalPuestos: PUESTOS_SEED.length,
                totalPostulaciones: POSTULACIONES_SEED.length,
                totalInformes: INFORMES_SEED.length,
                totalUsuarios: USUARIOS_SEED.length,
                totalAreas: AREAS_SEED.length,
                totalEtiquetas: ETIQUETAS_SEED.length,
            };
        }

        memoryStoreCandidatos = JSON.parse(JSON.stringify(CANDIDATOS_SEED));
        memoryStorePuestos = JSON.parse(JSON.stringify(PUESTOS_SEED));
        memoryStorePostulaciones = JSON.parse(JSON.stringify(POSTULACIONES_SEED));
        memoryStoreInformes = JSON.parse(JSON.stringify(INFORMES_SEED));
        memoryStoreUsuarios = JSON.parse(JSON.stringify(USUARIOS_SEED));
        memoryStoreAreas = JSON.parse(JSON.stringify(AREAS_SEED));
        memoryStoreEtiquetas = JSON.parse(JSON.stringify(ETIQUETAS_SEED));
        persistJson();

        return {
            totalCandidatos: memoryStoreCandidatos.length,
            totalPuestos: memoryStorePuestos.length,
            totalPostulaciones: memoryStorePostulaciones.length,
            totalInformes: memoryStoreInformes.length,
            totalUsuarios: memoryStoreUsuarios.length,
            totalAreas: memoryStoreAreas.length,
            totalEtiquetas: memoryStoreEtiquetas.length,
        };
    },

    // ==================== ETIQUETAS (Cualidades Reutilizables) ====================
    async obtenerEtiquetas() {
        if (this.isUsingMongo()) {
            const docs = await EtiquetaModel.find().sort({ nombre: 1 });
            return docs.map((d) => d.toJSON());
        }
        return [...(memoryStoreEtiquetas || [])].sort((a, b) => a.nombre.localeCompare(b.nombre));
    },

    async insertarEtiqueta(nombre) {
        const nombreLimpio = String(nombre || "").trim();
        if (!nombreLimpio) return null;

        if (this.isUsingMongo()) {
            const nombreEscapado = nombreLimpio.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
            const existe = await EtiquetaModel.findOne({
                nombre: { $regex: new RegExp(`^${nombreEscapado}$`, "i") },
            });
            if (existe) return existe.toJSON();

            const nuevoId = await siguienteIdMongo(EtiquetaModel, memoryStoreEtiquetas);
            const doc = await EtiquetaModel.create({ id: nuevoId, nombre: nombreLimpio });
            return doc.toJSON();
        }

        if (!memoryStoreEtiquetas) memoryStoreEtiquetas = [];
        const existe = memoryStoreEtiquetas.find(
            (e) => e.nombre.toLowerCase() === nombreLimpio.toLowerCase()
        );
        if (existe) return existe;

        const nuevoId = memoryStoreEtiquetas.length > 0
            ? Math.max(...memoryStoreEtiquetas.map((e) => Number(e.id) || 0)) + 1
            : 1;
        const nueva = { id: nuevoId, nombre: nombreLimpio };
        memoryStoreEtiquetas.push(nueva);
        persistJson("etiquetas");
        return nueva;
    },

    obtenerCatalogos() {
        return CATALOGOS_SEED;
    },
};
